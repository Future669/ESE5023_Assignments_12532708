```python
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
FILE_PATH = r"C:\Users\Future\Downloads\earthquakes.tsv"

# 读入并做清洗
df = pd.read_csv(FILE_PATH, sep="\t", low_memory=False)
df["Year"] = pd.to_numeric(df["Year"], errors="coerce")
df["Deaths"] = pd.to_numeric(df["Deaths"], errors="coerce").fillna(0)

# 自公元前2150年（-2150）以来
df = df[df["Year"] >= -2150]

#按"Country"（国家）分组，仅关注"Deaths"（死亡人数）列     dropna=False：即使国家列为缺失值（NaN），也将其归为一组（不丢弃）
grouped_by_country = df.groupby("Country", dropna=False)["Deaths"]

#对每个国家的死亡人数求和，得到"国家→总死亡人数"的Series（一维数据）
country_total_deaths = grouped_by_country.sum()

#按总死亡人数降序排序（从多到少，ascending=False表示降序）
sorted_deaths = country_total_deaths.sort_values(ascending=False)

#取排序后的前10条数据（死亡人数最多的10个国家）
top10_sorted = sorted_deaths.head(10)

#重置索引，将"Country"从"索引"转为普通列，生成DataFrame（二维表格）
top10_with_index = top10_sorted.reset_index()

#重命名列名，将"Deaths"改为"Total_Deaths"
top10 = top10_with_index.rename(columns={"Deaths": "Total_Deaths"})

#打印最终结果
print("死亡总人数排名前十的国家：")
print(top10.to_string(index=False))


#做1.2题
df["Mag"] = pd.to_numeric(df["Mag"], errors="coerce")
df = df.dropna(subset=["Year", "Mag"])    # 删除缺失年份或震级的记录

#筛选：自公元前 2150 年以来，且震级 > 6.0
df = df[df["Year"] >= -2150]
df_mag_gt6 = df[df["Mag"] > 6.0]

grouped_by_year = df_mag_gt6.groupby("Year")  #按年份分组（将震级>6.0的地震数据，按"Year"列归类
yearly_earthquake_count = grouped_by_year.size() #统计每年的地震次数
earthquake_count_df = yearly_earthquake_count.reset_index(name="Count") #转成表格和命名次数列
eq_counts = earthquake_count_df.sort_values(by="Year") #按年份升序排序

plt.figure(figsize=(10, 5))
plt.plot(eq_counts["Year"], eq_counts["Count"], linewidth=1.5)
plt.title("Global Earthquakes with Magnitude > 6.0 per Year")
plt.xlabel("Year")
plt.ylabel("Number of Earthquakes")
plt.grid(True)
plt.show()
print("图表中呈现的 “地震次数随时间剧增” 并非地震活动的自然趋势，而是人类对地震的 “记录能力” 从无到有、从弱到强的直接反映。")
print("古代因缺乏监测技术和记录手段，大量地震未被记载；近现代则因技术进步，地震数据被完整捕捉，从而呈现出 “地震次数剧增” 的视觉趋势。")

#做1.3题
for col in ["Year", "Mag", "Mo", "Dy", "Hr", "Mn", "Sec"]:
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

# 1.2 国家列做清洗
df["Country"] = df["Country"].astype(str).str.strip()
df["Country"] = df["Country"].replace({"": "Unknown"}).fillna("Unknown")

#辅助：把一行记录拼成“日期字符串” 
#说明：数据里没有完整 Date 列；这里用 Year / Mo / Dy（和可选 Hr/Mn/Sec）尽量组成
#对BCE（负年份）用“YYYY BCE”表示；没有月/日就只输出有的部分
def _format_date_from_row(row):
    def _int_or_none(x):
        # 尝试转 int，失败返回 None
        try:
            if pd.isna(x):
                return None
            return int(x)
        except Exception:
            return None

    y = _int_or_none(row.get("Year"))
    m = _int_or_none(row.get("Mo"))
    d = _int_or_none(row.get("Dy"))
    hr = _int_or_none(row.get("Hr"))
    mn = _int_or_none(row.get("Mn"))
    sc = _int_or_none(row.get("Sec"))

    if y is None:
        return ""

    # 年份字符串：BCE 用 “YYYY BCE”，CE 用四位年
    if y < 0:
        y_str = f"{abs(y)} BCE"
    else:
        y_str = f"{y:04d}"

    # 逐步拼接（有就拼，没有就省略）
    if m is None and d is None:
        date_str = y_str
    elif m is not None and d is None:
        date_str = f"{y_str}-{m:02d}"
    else:
        # m 与 d 同时存在才到天
        if m is not None and d is not None:
            date_str = f"{y_str}-{m:02d}-{d:02d}"
        else:
            date_str = y_str  # 不足则退回只显示年份

    # 如果有时间，再拼时间
    time_parts = []
    if hr is not None:
        time_parts.append(f"{hr:02d}")
        if mn is not None:
            time_parts.append(f"{mn:02d}")
            if sc is not None:
                time_parts.append(f"{sc:02d}")
    if time_parts:
        # 只有小时 -> "HH", 有分 -> "HH:MM", 有秒 -> "HH:MM:SS"
        if len(time_parts) == 1:
            date_str = f"{date_str} {time_parts[0]}"
        elif len(time_parts) == 2:
            date_str = f"{date_str} {time_parts[0]}:{time_parts[1]}"
        else:
            date_str = f"{date_str} {time_parts[0]}:{time_parts[1]}:{time_parts[2]}"

    return date_str

def CountEq_LargestEq(country_name: str):
    #统一匹配（忽略大小写与前后空格）
    key = str(country_name).strip().lower()

    #该国“自公元前2150年以来”的记录（用于统计总数）
    df_since_2150 = df[(df["Year"].notna()) & (df["Year"] >= -2150)]
    sub_since = df_since_2150[df_since_2150["Country"].str.lower() == key]
    total_count = len(sub_since)

    #该国“全时期”的记录（用于找最大震级及其日期）
    sub_all = df[df["Country"].str.lower() == key]

    if len(sub_all) == 0:
        # 该国完全不存在于数据中
        return 0, "", np.nan

    #如果Mag全是缺失，日期返回空
    if "Mag" not in sub_all or sub_all["Mag"].notna().sum() == 0:
        return total_count, "", np.nan

    #找到最大震级的那一行（若有并列，idxmax 会取第一条）
    idx_max = sub_all["Mag"].idxmax()
    largest_mag = sub_all.at[idx_max, "Mag"]

    #用Year/Mo/Dy/Hr/Mn/Sec尽量拼一个可读日期
    date_of_largest = _format_date_from_row(sub_all.loc[idx_max])

    return total_count, date_of_largest, largest_mag

#取国家列表（去空/去重）
countries = (
    df["Country"].astype(str).str.strip().replace("", np.nan).dropna().unique()
)

#逐国计算
rows = []
for c in countries:
    total_cnt, largest_date, largest_mag = CountEq_LargestEq(c)
    rows.append({
        "Country": c,
        "Total_Quakes_Since_2150BCE": total_cnt,
        "Largest_Mag": largest_mag,
        "Date_of_Largest_Eq": largest_date
    })

#汇总为 DataFrame，并按“地震总数”降序（并列时按最大震级降序）
res_df = pd.DataFrame(rows).sort_values(
    by=["Total_Quakes_Since_2150BCE", "Largest_Mag"],
    ascending=[False, False]
).reset_index(drop=True)

print(res_df.to_string(index=False))
```

    死亡总人数排名前十的国家：
       Country  Total_Deaths
         CHINA     2139210.0
        TURKEY     1199742.0
          IRAN     1014453.0
         ITALY      498219.0
         SYRIA      419226.0
         HAITI      323484.0
    AZERBAIJAN      319251.0
         JAPAN      242445.0
       ARMENIA      191890.0
      PAKISTAN      145083.0
    


    
![png](output_0_1.png)
    


    图表中呈现的 “地震次数随时间剧增” 并非地震活动的自然趋势，而是人类对地震的 “记录能力” 从无到有、从弱到强的直接反映。
    古代因缺乏监测技术和记录手段，大量地震未被记载；近现代则因技术进步，地震数据被完整捕捉，从而呈现出 “地震次数剧增” 的视觉趋势。
                                         Country  Total_Quakes_Since_2150BCE  Largest_Mag  Date_of_Largest_Eq
                                           CHINA                         592          8.5          1668-07-25
                                           JAPAN                         361          9.1 2011-03-11 05:46:24
                                       INDONESIA                         340          9.1 2004-12-26 00:58:53
                                            IRAN                         263          7.9          0856-12-22
                                             USA                         229          9.2 1964-03-28 03:36:16
                                          TURKEY                         224          7.8 1939-12-26 23:57:23
                                          GREECE                         181          8.0          0365-07-21
                                            PERU                         157          8.8          1716-02-06
                                           CHILE                         148          9.5 1960-05-22 19:11:17
                                          RUSSIA                         148          9.0 1952-11-04 16:58:27
                                          MEXICO                         144          8.6    1787-03-28 17:30
                                     PHILIPPINES                         142          8.7    1897-09-21 05:12
                                           ITALY                         105          7.5 1915-01-13 06:52:38
                                PAPUA NEW GUINEA                          99          8.2 1919-05-06 19:41:13
                                          TAIWAN                          98          8.2 1920-06-05 04:21:35
                                           INDIA                          86          8.6 1950-08-15 14:09:30
                                        COLOMBIA                          68          8.2 1826-06-18 03:40:00
                                     NEW ZEALAND                          66          8.0                1826
                                     AFGHANISTAN                          62          8.1 1909-07-07 21:37:50
                                 SOLOMON ISLANDS                          62          8.1 1977-04-21 04:24:09
                                         ECUADOR                          58          8.8 1906-01-31 15:36:10
                                         VANUATU                          57          8.1 1913-10-14 08:08:48
                                        PAKISTAN                          44          8.0 1945-11-27 21:56:50
                                         ALGERIA                          39          7.1 1980-10-10 12:25:26
                                       GUATEMALA                          37          7.7 1942-08-06 23:37:02
                                         ALBANIA                          35          7.5          1893-06-14
                                       VENEZUELA                          30          8.0    1530-09-01 14:30
                                 MYANMAR (BURMA)                          29          8.0 1912-05-23 02:24:06
                                      COSTA RICA                          29          7.7 1950-10-05 16:09:31
                                   NEW CALEDONIA                          28          8.0          1875-03-28
                                       NICARAGUA                          28          7.9    1898-04-29 16:18
                                       ARGENTINA                          28          7.5    1894-10-27 19:30
                                      TAJIKISTAN                          28          7.4 1907-10-21 04:23:36
                                     EL SALVADOR                          25          7.9          1776-05-30
                                       AUSTRALIA                          24          8.2 1989-05-23 10:54:46
                                   USA TERRITORY                          23          8.1 1902-09-22 01:46:30
                  KERMADEC ISLANDS (NEW ZEALAND)                          23          8.1 1986-10-20 06:46:09
                                           TONGA                          21          8.1 1919-04-30 07:17:17
                                     SOUTH KOREA                          21          6.5          1643-07-25
                                          PANAMA                          20          8.3 1882-09-07 07:50:00
                                           NEPAL                          19          8.2          1505-06-06
                                            FIJI                          17          8.3 1919-01-01 02:59:57
                                          CANADA                          17          8.1 1949-08-22 04:01:12
                                      KYRGYZSTAN                          15          8.0 1911-01-03 23:25:49
                                          FRANCE                          15          8.0 1817-03-11 20:10:00
                                      BANGLADESH                          15          7.6 1918-07-08 10:22:07
                                         GEORGIA                          15          7.5 1905-10-21 11:01:37
                                           SPAIN                          15          7.5          0881-05-26
                                      AZERBAIJAN                          14          6.9             1667-11
                                        SLOVENIA                          14          6.5    1511-03-26 14:30
                                    SOUTH AFRICA                          13          7.9 1942-11-10 11:41:27
                                         ROMANIA                          13          7.5 1977-03-04 19:21:55
                                        BULGARIA                          12          7.8    1904-04-04 10:27
                                         CROATIA                          12          7.2    1667-04-06 07:10
                                         UKRAINE                          12          7.0                0103
                                      UZBEKISTAN                          12          7.0 1976-04-08 02:40:27
                                    TURKMENISTAN                          11          8.2    1895-07-08 21:30
                                           HAITI                          11          8.0       1842-05-07 21
                               AZORES (PORTUGAL)                          11          7.6          1968-02-28
                                        HONDURAS                          10          7.6 2025-02-08 23:23:14
                                          BRAZIL                          10          7.6 1963-11-09 21:15:32
                                          SERBIA                          10          6.0 1922-03-24 12:22:00
                                      KAZAKHSTAN                           9          8.3 1889-07-11 22:14:00
                                          ISRAEL                           9          7.0        31 BCE-09-02
                              BOSNIA-HERZEGOVINA                           9          6.4 1969-10-27 08:10:00
                                        PORTUGAL                           8          8.5              60 BCE
                                           SAMOA                           8          8.3 1917-06-26 05:49:42
                                         BOLIVIA                           8          8.2 1994-06-09 00:33:16
                              DOMINICAN REPUBLIC                           8          7.9 1946-08-04 17:51:05
                                        TANZANIA                           8          7.3 1910-12-13 11:37:28
                                         ARMENIA                           8          6.8 1988-12-07 07:41:24
                                        ETHIOPIA                           8          6.5 1906-08-25 13:47:37
                                       MACEDONIA                           8          6.2 1979-05-24 17:23:18
                                          POLAND                           8          4.8 2004-09-21 13:32:30
    SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS                           7          8.1 1929-06-27 12:47:13
                                            CUBA                           7          7.7 2020-01-28 19:10:25
                                           EGYPT                           7          7.2 1995-11-22 04:15:11
                                           CONGO                           7          7.0 1992-09-11 03:57:26
                                              UK                           7          6.2          1580-04-06
                                        MONGOLIA                           6          8.4 1905-07-09 09:40:24
                                      ANTARCTICA                           6          8.1 1998-03-25 03:12:25
                                  ATLANTIC OCEAN                           6          7.8 1941-11-25 18:03:57
                             TRINIDAD AND TOBAGO                           6          7.5    1888-01-10 12:55
                                         ICELAND                           6          7.5 1912-05-06 18:59:00
                                         VIETNAM                           6          6.8 1935-11-01 16:22:09
                                     NORTH KOREA                           6          6.7          1518-07-02
                                      GUADELOUPE                           5          8.3 1843-02-08 14:50:00
                                          JORDAN                           5          7.3            2150 BCE
                                      MONTENEGRO                           5          6.9 1979-04-15 06:19:44
                                         HUNGARY                           5          6.8 1834-10-15 06:30:00
                                           GHANA                           5          6.5 1862-07-10 08:15:00
                                          BHUTAN                           5          6.1 2009-09-21 08:53:05
                                          RWANDA                           5          5.8 2015-08-07 01:25:02
                                         GERMANY                           5          5.3 1978-09-03 05:08:30
                                           SYRIA                           4          7.6    1202-05-20 02:40
                                         LEBANON                           4          7.4          1759-11-25
                                     SOUTH SUDAN                           4          7.1 1990-05-20 02:22:01
                                          UGANDA                           4          6.8          1912-07-09
                                         MOROCCO                           4          6.8 2023-09-08 22:11:01
                                     SWITZERLAND                           4          6.2          1601-09-18
                                         ERITREA                           4          6.2          1875-11-02
                                          MALAWI                           4          6.1 1989-03-10 21:49:45
                                    INDIAN OCEAN                           3          8.1 1928-03-09 18:05:27
                                      MARTINIQUE                           3          7.9 1906-12-03 22:59:00
                                         JAMAICA                           3          7.8    1899-06-14 11:09
                      MICRONESIA, FED. STATES OF                           3          7.7 1911-08-16 22:41:18
                                      MOZAMBIQUE                           3          7.0 2006-02-22 22:19:07
                                         AUSTRIA                           3          6.6          1590-09-15
                                            IRAQ                           3          6.4          1864-12-02
                                          CYPRUS                           3          6.3 1953-09-10 04:06:04
                                        MALAYSIA                           3          6.2 1976-07-26 02:56:39
                                        THAILAND                           3          6.1 2014-05-05 11:08:43
                                           YEMEN                           3          6.0 1982-12-13 09:12:48
                                    SAUDI ARABIA                           3          5.7 2009-05-19 17:35:00
                                     NETHERLANDS                           3          5.2 1992-04-13 01:20:00
                             ANTIGUA AND BARBUDA                           2          8.0          1690-04-16
                                   PACIFIC OCEAN                           2          7.5          1932-11-02
                                     SOLOMON SEA                           2          7.3    1895-03-06 08:35
                                            OMAN                           2          7.0                1570
                                           KENYA                           2          6.9 1928-01-06 19:31:58
                                            LAOS                           2          6.3 2007-05-16 08:56:16
                                   COTE D'IVOIRE                           2          5.7       1879-02-11 06
                                         TUNISIA                           2          5.6 1957-02-20 04:41:01
                                        KIRIBATI                           1          7.6 1905-06-30 17:07:00
                                           PALAU                           1          7.6 1914-10-23 06:18:34
                                    UK TERRITORY                           1          7.6 1983-11-30 17:46:00
                                   FRENCH GUIANA                           1          6.9    1885-08-04 09:43
                                      BERING SEA                           1          6.7 1991-02-21 02:35:34
                                      TASMAN SEA                           1          6.6    1892-01-26 16:48
                                FRENCH POLYNESIA                           1          6.5          1848-07-12
            WALLIS AND FUTUNA (FRENCH TERRITORY)                           1          6.4 1993-03-12 14:01:35
                                        DJIBOUTI                           1          6.3 1989-08-20 11:16:56
                                        CAMEROON                           1          6.2 1945-09-12 00:51:00
                                           GABON                           1          6.2 1974-09-23 19:28:17
                                          GUINEA                           1          6.2 1983-12-22 04:11:29
                                          ZAMBIA                           1          5.9 2017-02-24 00:32:17
                                         COMOROS                           1          5.9 2018-05-15 15:48:09
                                          NORWAY                           1          5.8          1819-08-31
                                            TOGO                           1          5.6                1788
                                           SUDAN                           1          5.5 1993-08-01 00:20:40
                                      MADAGASCAR                           1          5.5 2017-01-11 22:06:58
                                           LIBYA                           1          5.4 1963-02-21 17:14:31
                                    SIERRA LEONE                           1          5.2       1795-05-20 22
                                         BELGIUM                           1          5.0 1983-11-08 00:49:32
                        CENTRAL AFRICAN REPUBLIC                           1          4.8 1921-09-16 00:51:00
                                         BURUNDI                           1          4.7 2004-02-24 02:14:34
                                  CZECH REPUBLIC                           1          4.1 2008-11-22 22:27:55
                                        SLOVAKIA                           1          2.2 2004-01-10 07:43:18
    


```python
import pandas as pd
import matplotlib.pyplot as plt

file_path = r"C:\Users\Future\Downloads\2281305.csv"

#读取 CSV
df = pd.read_csv(file_path, encoding="utf-8-sig", low_memory=False)

# 拆分 WND: 方向, 方向QC, 类型, 风速(0.1 m/s), 风速QC
parts = df["WND"].astype(str).str.split(",", expand=True)
speed_raw = pd.to_numeric(parts[3], errors="coerce")
speed_qc  = pd.to_numeric(parts[4], errors="coerce")

#过滤（按用户指南POS 66–70）
#合法风速：0–900 (代表 0.0–90.0 m/s)
#质量码：保留 0/1/4/5
mask = speed_raw.between(0, 900) & speed_qc.isin([0, 1, 4, 5])
df = df[mask].copy()

#换算单位：m/s
df["wind_mps"] = speed_raw[mask] / 10.0

# 时间处理与筛选：2010–2020
df["DATE"] = pd.to_datetime(df["DATE"], errors="coerce")
df = df[(df["DATE"].dt.year >= 2010) & (df["DATE"].dt.year <= 2020)]

#月均风速
monthly = (
    df.groupby(df["DATE"].dt.to_period("M"))["wind_mps"]
      .mean()
      .reset_index()
      .rename(columns={"DATE": "YearMonth"})
)
monthly["YearMonth"] = monthly["YearMonth"].astype(str)

#画图
plt.figure(figsize=(12, 5))
plt.plot(monthly["YearMonth"], monthly["wind_mps"], lw=1.5)
plt.title("Monthly Averaged Wind Speed (2010–2020)")
plt.xlabel("Year-Month")
plt.ylabel("Wind Speed (m/s)")
step = 6
plt.xticks(range(0, len(monthly), step), monthly["YearMonth"].iloc[::step], rotation=45)
plt.grid(True)
plt.tight_layout()
plt.show()

print("从 2010 到 2020 年的月平均风速并无明显趋势，整体呈现逐年波动状态，虽在2015、2017、2020 年出现峰值，但未形成持续的上升或下降走势。")
```


    
![png](output_1_0.png)
    


    从 2010 到 2020 年的月平均风速并无明显趋势，整体呈现逐年波动状态，虽在2015、2017、2020 年出现峰值，但未形成持续的上升或下降走势。
    


```python
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

#数据加载与清洗  2013-2023 年中国境内地震位置、震级及深度数据集
file_path = r"C:\Users\Future\Downloads\query.csv"
df = pd.read_csv(file_path, encoding="gb18030")

# 删除缺失值与异常值
df = df.dropna(subset=["time", "mag", "depth"])
df = df[(df["mag"] > 0) & (df["depth"] >= 0)]

# 转换时间列
df["time"] = pd.to_datetime(df["time"], errors="coerce").dt.tz_localize(None)
df["YearMonth"] = df["time"].dt.to_period("M")

# 绘制震级时间序列   按月取平均震级
df["YearMonth"] = df["time"].dt.to_period("M")
monthly_mag = df.groupby("YearMonth")["mag"].mean().reset_index()

plt.figure(figsize=(12, 5))
plt.plot(monthly_mag["YearMonth"].astype(str), monthly_mag["mag"], lw=1.5)
plt.title("Monthly Average Earthquake Magnitude in China (2013–2023)")
plt.xlabel("Year-Month")
plt.ylabel("Average Magnitude")
plt.xticks(range(0, len(monthly_mag), 6), monthly_mag["YearMonth"].iloc[::6], rotation=45)
plt.grid(True)
plt.tight_layout()
plt.show()

#统计分析
print("数据统计结果：")
print(f"数据时间范围: {df['time'].min()} 至 {df['time'].max()}")
print(f"记录总数: {len(df)}")
print(f"平均震级: {df['mag'].mean():.2f}")
print(f"最大震级: {df['mag'].max()}")
print(f"最小震级: {df['mag'].min()}")
print(f"平均震源深度: {df['depth'].mean():.2f} km")
print(f"最深震源深度: {df['depth'].max():.3f} km")


bins = [0, 3, 4, 5, 6, 7, 10]
labels = ["<3", "3–4", "4–5", "5–6", "6–7", "≥7"]
df["mag_category"] = pd.cut(df["mag"], bins=bins, labels=labels, include_lowest=True)

print("\n震级区间统计：")
print(df["mag_category"].value_counts().sort_index().to_string(index=True))


```


    
![png](output_2_0.png)
    


    数据统计结果：
    数据时间范围: 2018-01-01 19:22:03.580000 至 2023-02-04 07:34:41.538000
    记录总数: 4828
    平均震级: 4.52
    最大震级: 7.3
    最小震级: 2.6
    平均震源深度: 29.92 km
    最深震源深度: 584.069 km
    
    震级区间统计：
    mag_category
    <3        3
    3–4     252
    4–5    4189
    5–6     358
    6–7      25
    ≥7        1
    


```python

```


```python

```
